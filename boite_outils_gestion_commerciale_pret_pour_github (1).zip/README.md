# Boîte à outils de gestion commerciale

## Description
Ce dépôt regroupe quatre petits programmes Python pour effectuer des calculs simples de gestion commerciale.

## Contenu du dépôt

| Fichier | Rôle |
|---|---|
| `marge.py` | Calcule la marge commerciale, le taux de marge et le taux de marque. |
| `tva.py` | Calcule le montant de la TVA et le montant TTC. |
| `interets.py` | Calcule les intérêts simples et le montant final. |
| `total_ventes.py` | Calcule le total et la moyenne des ventes à partir du fichier CSV. |
| `ventes.csv` | Contient les données de ventes utilisées par `total_ventes.py`. |

## Prérequis
- Python 3 installé.
- Aucun module externe à installer.

## Installation
1. Télécharger ou cloner ce dépôt.
2. Ouvrir un terminal dans le dossier `boite_outils_gestion_commerciale`.

## Exécution
Lancer chaque programme séparément :

```bash
python marge.py
python tva.py
python interets.py
python total_ventes.py
```

Pour `total_ventes.py`, garder le fichier `ventes.csv` dans le même dossier que le programme.

## Exemples de calculs
- `marge.py` : saisir le prix d'achat HT puis le prix de vente HT.
- `tva.py` : saisir le montant HT puis le taux de TVA.
- `interets.py` : saisir le capital, le taux annuel et la durée en années.
- `total_ventes.py` : lire les ventes enregistrées dans `ventes.csv`.

## Auteur
À compléter par l'étudiant(e).
